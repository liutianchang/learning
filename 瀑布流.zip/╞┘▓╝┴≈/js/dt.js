 var a = new Array("image/1.jpg", "image/2.jpg", "image/3.jpg", "image/4.jpg", "image/5.jpg", "image/6.jpg");
 var num = 0;

function disp() {
     if (num == a.length - 1)
         num = 0;
     else
         num++;
     document.img1.src = a[num];
     setTimeout("disp()", 1000);
 }